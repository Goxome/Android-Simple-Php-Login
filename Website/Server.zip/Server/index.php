<?php
// Conexão
require_once 'DB.php';

// Sessão
session_start();

// Botão enviar
if(isset($_POST['btn-entrar'])):
  $erros = array();
  $login = mysqli_escape_string($conn, $_POST['login']);
  $senha = mysqli_escape_string($conn, $_POST['senha']);

  if(isset($_POST['lembrar-senha'])):

    setcookie('login', $login, time()+3600);
    setcookie('senha', md5($senha), time()+3600);
  endif;

  if(empty($login) or empty($senha)):
    $erros[] = "<li> O campo login/senha precisa ser preenchido </li>";
  else:
    // 105 OR 1=1 
      // 1; DROP TABLE teste

    $sql = "SELECT login FROM usuarios WHERE login = '$login'";
    $resultado = mysqli_query($conn, $sql);   

    if(mysqli_num_rows($resultado) > 0):
    $senha = md5($senha);       
    $sql = "SELECT * FROM usuarios WHERE login = '$login' AND senha = '$senha'";



    $resultado = mysqli_query($conn, $sql);

      if(mysqli_num_rows($resultado) == 1):
        $dados = mysqli_fetch_array($resultado);
        mysqli_close($conn);
        $_SESSION['logado'] = true;
        $_SESSION['id_usuario'] = $dados['id'];
        header('Location: dashboard');
      else:
        $erros[] = "<li> El Usuario No Existe </li>";
      endif;

    else:
      $erros[] = "<li> Usuario Incorrecto </li>";
    endif;

  endif;

endif;
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="https://cutt.ly/aQdaRGX">
</head>
<body>
    <div class="container">
          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" class="form" >

<?php 
if(!empty($erros)):
  foreach($erros as $erro):
    echo $erro;
  endforeach;
endif;
?>
              <img src="" class="logo" alt="">
              <div class="form-ctrl">
                  <img src="" class="user" alt="">
                  <input type="text" name="login" placeholder="Username">
              </div>
              <div class="form-ctrl r">
                  <input type="password" name="senha" placeholder="Password">
                  <look src="" class="look" alt="">
            </div>
            <button class="btn" name="btn-entrar">Login</button>
          </form>
    </div>
</body>
</html>